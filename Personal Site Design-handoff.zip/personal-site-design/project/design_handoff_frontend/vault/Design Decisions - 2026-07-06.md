---
tags:
  - personal-site
  - design
  - decision-log
type: decision-log
status: current
created: 2026-07-06
updated: 2026-07-06
---

# Design Decisions — 2026-07-06

Hi-fi exploration session for richardkern.nz (Claude project "Personal Site Design", file `Design Explorations.dc.html`, turns 1–5). Each decision below names the mock it came from. [[Design Spec]] has been updated to match; this note is the why.

## Decisions

1. **Homepage gets bolder; inner pages stay understated** (turn 2). The spec's quiet serif intro read safe. The name now sits at cover scale; detail pages keep reading comfort as the job.
2. **Wordmark replaces monogram** (2d → 3d). None of the RK monogram marks (1g) earned their place. Chosen: **w4** — `richardkern.nz` in Geist Mono, lowercase, Fern/Moss `.nz`. Quieter and more technical than the Bricolage wordmark (w1), and it lets the display face carry personality in the name instead. Header 16px (raised from 14 — must beat the 13px nav), footer 12.5px, spine vertical.
3. **Palette tuned green** (3b vs 3a). The spec darks (`#14181D`, `#1F242B`) were blue-cast and read "tech UI" against the NZ-bush story. Now: Bush Charcoal `#171B16`, Ink `#22261F`, Paper warmed to `#F7F5EF`. Fern unchanged. **Moss `#8FB8A5` promoted to a named token** — the accent-on-charcoal (Fern fails contrast there); it was already being used informally.
4. **Display face: Schibsted Grotesk, not Bricolage** (4b over 4a serif / 4c Newsreader italic). Bricolage didn't land at display sizes; Richard prefers the sans. Schibsted is characterful without quirk and isn't (yet) an AI-default face. Type system is otherwise unchanged: Source Serif 4 body, Geist UI, Geist Mono code+meta.
5. **Theme stays field notebook, with a logbook layer** (turn 4; alternatives considered: pure logbook, NZ topo map, workshop — rejected as colder / decorative / kitsch). The logbook layer: entry N° + date in a mono rail on indexes and home, mono meta line on posts. **N° must be real** — chronological position from Payload, or it violates the "structural devices must encode something true" standard.
6. **Chrome locked** (3d + 1d): paper header with mono wordmark + Geist nav (Fern underline = active); Bush Charcoal footer with wordmark, nav, socials, small print. Home keeps no header/footer — spine + plain top-right nav (2c's plainness, without the vertical-name spine which cost legibility).
7. **All pages mocked in the locked system** (turn 5): post 5a, posts index 5b, work index 5c, project 5d, about 5e, 404 5f ("This page isn't in the log."). These are the pixel reference for Phase 03.

## Rejected along the way

- Full-viewport dark cover / charcoal top panel (2b) — strongest single image, but heavier than "consistently understated" allows everywhere except… it lost to the spine anyway.
- Vertical full-height name as the spine (2c hero) — distinctive, poor legibility.
- Serif display (4a) and Newsreader italic display (4c) — bookish/warm but Richard prefers the sans.
- All five monograms (1g).
- Bookmark-ribbon home without spine (1c) — traded the signature move for a conventional shape.

## Follow-ups

- [ ] Replace `src/app/(frontend)/page.tsx` — the current dark homepage predates even the 2026-07-05 spec.
- [ ] Swap Bricolage → Schibsted Grotesk in Phase 03 font loading plan; Source Serif 4 + Geist already planned/loaded.
- [ ] Derive entry N° from published-post count (display device, may shift on unpublish — accepted).
- [ ] Favicon: `rk.` mono on Bush Charcoal; Fern dot alone at 16px.
- [ ] Design-system formalisation (tokens file / reference note) once Phase 03 starts — palette + type tables in [[Design Spec]] §4 are the source of truth until then.

## Related

- [[Design Spec]]
- [[Personal Site Overview]]
- [[Phase 03 - Frontend]]
- [[Claude Web Design Standards]]
