---
tags:
  - personal-site
  - design-spec
  - project
type: design-spec
status: active
created: 2026-07-05
updated: 2026-07-06
---

# Design Spec: richardkern.nz

Built from [[PRD]] (agreed 2026-07-05). This document is the handoff: a cold implementation session builds from this without access to the conversation that produced it. The site is partially built — schema complete, homepage started, inner pages scaffolded from the Payload website template — so parts of this spec describe intent for existing code, not greenfield work.

> **Revision 2026-07-06:** visual direction refined through hi-fi exploration (Claude "Personal Site Design" project, `Design Explorations.dc.html`, turns 1–5). Display face changed Bricolage Grotesque → **Schibsted Grotesk**; palette warmed and green-cast (see §4); monogram dropped in favour of a **mono wordmark**; **logbook flavour** added to the notebook theme. The homepage in the current codebase predates all of this and the 2026-07-05 spec — treat it as disposable.

## 1. Information architecture

### Sitemap and URLs

```
/                    Home — paper page with a charcoal "spine" rail, no header/footer
/posts               Posts index, paginated at /posts/page/[n]
/posts/[slug]        Individual post
/work                Work index
/work/[slug]         Individual project
/about               About (a Pages collection doc, routed via /[slug])
/admin               Payload admin (not in nav)
```

Nav items (header on inner pages, sidebar on home): **Posts, Work, About**. The site name links home.

Decided at the IA gate (2026-07-05):
- `/posts` stays (not `/blog`).
- Tag browsing is a **filter on the index pages** (`/posts?tag=homelab`, `/work?tag=...`), server-rendered. No dedicated tag pages at launch.
- The template's `/search` page is **deleted** at launch (search is a PRD non-goal; it returns from the Later list when there is content to search). The template's `next/seed` demo route is also deleted. The `next/preview` / `next/exit-preview` routes stay — they serve Payload draft preview.
- RSS feed at `/feed.xml` (a PRD Should).

### Page purposes

- **Home** exists so that a first-time visitor can grasp who Richard is, see he's active, see he builds real things, and follow him in one click.
- **/posts** exists so that a reader can scan everything written and pick a post.
- **/posts/[slug]** exists so that a reader arriving from search or a shared link can read the post, judge the author credible, and follow him. Highest-traffic entry point; most visitors never see the homepage.
- **/work** exists so that an evaluator can scan what Richard has built at a glance.
- **/work/[slug]** exists so that an evaluator can understand one project: what, why, the tech, and where it lives.
- **/about** exists so that an evaluator can learn who Richard is and reach him. Carries the "soft signal" for client work: capability evident, nothing pitched, no CTA.

## 2. Content model

Schema is already built and running; this records what exists and why. Regenerate types after any change (`pnpm generate:types`).

### Collections

- **Posts** — repeating editorial content. title, slug, content (Lexical with code block + inline code features), publishedAt, tags (→ Tags, hasMany), coverImage (→ Media), SEO fields, drafts/versions for draft-vs-published.
- **Projects** — repeating portfolio entries. title, slug, description (short text), longDescription (Lexical), tech (text array), url, repoUrl, coverImage (→ Media), gallery images (→ Media), year, featured (bool), tags, drafts/versions. Admin UI tabbed: Content / Media / Links.
- **Tags** — flat taxonomy: name, slug. Shared by Posts and Projects so one vocabulary spans both.
- **Pages** — rare standalone pages (About now; Uses/Now later), block-based, routed at `/[slug]`.
- **Media** — uploads with alt text. Local disk in dev, Cloudflare R2 in production (pre-launch task).
- **Users** — auth, admin-only. No public accounts.

### Globals

- **SiteSettings** — siteTitle, bio, socialLinks (array: platform + url), navConfig. Feeds homepage sidebar, footer, and post bylines. Changing a social URL is never a deploy.
- **Header / Footer** — inner-page chrome nav.

### Hardcoded

Homepage layout and its queries (3 recent published posts; up to 3 featured published projects), fonts, route structure. Changes only with a redesign.

### Editor experience and access

Sole editor is Richard (technical). Optimise for publishing speed: the PRD target is vault draft → published post in under 30 minutes. Access control is the standard pattern: public read of published docs only, authenticated create/update, no public mutation. Frontend queries must never leak drafts.

## 3. Page-by-page spec

Intent, not pixels; pixel reference is the exploration file (turn 5 = locked system). Content source per section in parentheses.

### Home `/` (mock: turn 4b/3b composite)

Paper page with a charcoal **spine**: a narrow full-height rail (~86px) on the left edge, the notebook's spine. No header or footer.

1. **Spine rail (persistent, Bush Charcoal):** vertical mono wordmark at top (reading bottom-up), social links stacked at the bottom as small circled mono glyphs (SiteSettings.socialLinks). The follow action is pinned here permanently. At mobile widths the spine becomes a slim charcoal top bar; wordmark and social links remain visible on the first screen at 375px (mock: 6a).
2. **Main column (paper):** plain nav top-right (Posts, Work, About), then the name at cover scale — lowercase Schibsted Grotesk (~108px desktop, two lines: `richard` / `kern` with a Fern full stop) — followed by a one-line serif bio (SiteSettings) set as a sentence, not a hero slogan.
3. **Writing:** 3 most recent published posts as logbook entries — mono rail (entry N° + date) beside a serif title (Posts). "Full log →" links to /posts.
4. **Selected work:** up to 3 featured published projects — mono year rail, serif title, one-line description (Projects). "All work →".

Writing and work sit side by side at desktop widths, stack at mobile. Actions: open post, open project, follow, navigate.

### Posts index `/posts` (mock: 5b)

All published posts, newest first, paginated. Entry: logbook rail (entry N° + date, Geist Mono) beside Schibsted title, serif description, Fern tag links (Posts). Tag filter via `?tag=` is a quiet text row under the H1; active filter is Fern with an underline, dismissible via "All". With one post, pagination controls don't render (pagination as `p.1 / 2` mono + "Older →"). Empty filter result states say so plainly.

**Entry numbers are real:** N° is the post's chronological position (first post = N°01), derived from published posts in Payload. If a post is unpublished the numbering may shift; acceptable — it is a display device, not an identifier.

### Post `/posts/[slug]` (mock: 5a)

The page must deliver the full "credible author, follow him" experience standalone.

1. **Header (meta):** one mono line — `N°06 · 14.06.2026 · tags` (tags in Fern) — then the title in Schibsted Grotesk (~46px), cover image if set (Posts).
2. **Body:** Lexical content. Reading comfort is the job: Source Serif body ~19px, line-height ~1.7, measure ~65–75ch. Code blocks are Bush Charcoal surfaces, radius 6, with a mono filename caption and Geist Mono 14px; syntax palette stays in-family (Moss keywords, warm-sand strings `#D9C79E`, grey-green comments) — no acid green.
3. **Byline/footer:** hairline rule, one italic serif line on the author with Fern social links (SiteSettings) and "← Full log" back to `/posts`.

Full metadata per post; OG image (Should — generation approach is implementer's choice).

### Work index `/work` (mock: 5c)

Published projects, featured first then year descending, two-up grid. Entry: cover image, title (Schibsted), one-line description, year + "featured" in mono, tech list in mono Fern (Projects). An evaluator gauges range at a glance.

### Project `/work/[slug]` (mock: 5d)

1. **Header:** mono meta line (year · tech list), title, then live and repo links in Fern where present (Projects). The links are the proof; they sit at the top.
2. **Body:** longDescription — what it is and the decisions behind it. Serif, same comfort rules as posts.
3. **Gallery:** images if present, two-up.

### About `/about` (mock: 5e)

Pages collection content: who Richard is, what he works with, ending in social links above a hairline (Pages + SiteSettings). Soft signal only — no services pitch, no CTA.

### 404 (mock: 5f)

Header only (no footer). Mono eyebrow `N°404 · entry not found`, headline "This page isn't in the log.", one serif line, links to Posts and Work.

### Inner-page chrome (mock: 3d, wordmark at 16px)

Header: mono wordmark 16px (→ home) + Posts / Work / About in Geist 13px; active section is Fern with a 1.5px underline; hairline bottom border. Footer: Bush Charcoal surface — mono wordmark 12.5px (Moss `.nz`), nav, social links, small print.

## 4. Visual direction — "Cover & Pages" (chosen 2026-07-05, refined 2026-07-06)

A hardback field notebook with a drop of logbook: quiet readable pages, the dark cover material showing only at the spine, and entries that are numbered and dated like a log. Green like NZ bush, not like a terminal. Deliberately avoids the cream-and-terracotta and dark-and-acid-green AI clusters, and every hard ban in [[Claude Web Design Standards]], which governs all visual work on this build.

### Palette (tuned 2026-07-06 — darks green-cast, paper warmed)

| Name | Hex | Use |
|---|---|---|
| Bush Charcoal | `#171B16` | homepage spine rail, footer, code blocks |
| Paper | `#F7F5EF` | page background; text on charcoal |
| Ink | `#22261F` | body text on paper |
| Fern | `#2A5A43` | accent on paper: links, tags, active nav, focus marks |
| Moss | `#8FB8A5` | accent on charcoal (Fern fails contrast there): wordmark `.nz`, code keywords |
| Haze | `#5E6459` | muted text on paper (AA at small sizes); on charcoal use `rgba(247,245,239,.65)` |

One accent family (Fern/Moss are the same hue at two lightnesses). Do not add a second accent. Verify all pairs AA per surface at build time.

### Type (display face changed 2026-07-06)

| Role | Face | Notes |
|---|---|---|
| Display | Schibsted Grotesk | headings and the homepage name; 600–700, tight tracking (−.02 to −.035em) |
| Body | Source Serif 4 | post and project long-form body; also index descriptions and entry titles on home |
| UI | Geist Sans | nav, buttons, labels, short descriptions (already loaded) |
| Code + meta | Geist Mono | code blocks, inline code, **and the logbook layer**: wordmark, entry N°/dates, tech lists, annotations (already loaded) |

Bricolage Grotesque is out (2026-07-06 — didn't land at display sizes). Load via `next/font` (self-hosted), `font-display: swap`, real fallbacks. Schibsted Grotesk and Source Serif 4 are on Google Fonts / self-hostable. Explicit scale: tighter leading and tracking at display sizes, ~1.6–1.7 line-height for serif body.

### Wordmark (decided 2026-07-06 — replaces the monogram; no monogram anywhere)

`richardkern.nz` in Geist Mono 500, lowercase, with the `.nz` in Fern on paper / Moss on charcoal.
- Inner header: 16px. Footer: 12.5px. Homepage spine: vertical (writing-mode, reading bottom-up) 13px.
- Favicon derives from it: lowercase `rk.` mono on Bush Charcoal, or Fern `.` alone at 16px sizes.

### Signature moves

1. **Charcoal where structural** (unchanged): the homepage spine rail, code blocks inside posts, and the footer. The site is one paper surface throughout; the charcoal is the cover material showing at the edge and in glimpses.
2. **The logbook layer** (added 2026-07-06): everything *about* an entry — numbers, dates, tech, filenames — is small Geist Mono; everything *in* an entry is serif. Entry N° must be real (chronological post count). This is flavour within the notebook theme, not a competing metaphor.

Don't add devices beyond these two.

### Motion

At most one considered moment (e.g. a single homepage reveal). No per-section scroll fade-ins. Respect `prefers-reduced-motion`.

## 5. Fixed — the implementer must not reopen these

- Sitemap, URLs, and nav as in §1, including `/posts` (not `/blog`), tag-filters-not-tag-pages, and deleting `/search` and `next/seed`.
- The content model in §2. Schema exists; extend only if a §3 requirement is impossible without it.
- The refined direction: palette values, type roles (Schibsted Grotesk display), the mono wordmark (no monogram), and both signature moves in §4.
- Homepage is a paper page with a persistent charcoal spine rail and no header/footer; inner pages use header + footer. The spine carries the vertical wordmark and social links.
- Primary action: social links one click away on homepage and every post.
- About stays soft-signal: no services pitch, no CTA.
- Every hard ban and the end-of-build checklist in [[Claude Web Design Standards]].
- Drafts never render publicly.

## 6. Implementer's choice

Resolved 2026-07-06 (were open):
- ~~Index entry treatment~~ → list with logbook rail (5b); work index two-up with covers (5c).
- ~~Tag filter UI / active-filter affordance~~ → quiet text row, Fern underline for active (5b).
- ~~Code block theme~~ → Bush Charcoal surface, mono filename caption, Moss/warm-sand/grey-green syntax (5a).
- ~~Favicon direction~~ → derived from wordmark (§4).
- ~~404~~ → "This page isn't in the log." (5f).

Still open:
- Component structure, file organisation, and how much of the template's block system to keep for Pages.
- Exact type scale values, spacing rhythm, grid, and breakpoint behaviour (within the standards skill; test 375/768/1024/1440). Turn-5 mocks give desktop values; mobile beyond the 375 home pattern is implementer's choice.
- Cover image and gallery presentation details beyond 16:10 two-up; aspect ratios per image.
- OG image approach (static template vs generated).
- RSS implementation details.
- Date formatting consistency (mocks use `DD.MM.YYYY` in the logbook layer — keep or vary), reading-time display (optional).
- The single motion moment, or none.

## Open items carried from the PRD

- Westgate Baptist portfolio entry: confirm the church is happy being showcased, and whether the entry waits until their site is live.

## Related

- [[PRD]]
- [[Personal Site Overview]]
- [[Content Architecture]]
- [[Personal Site Stack Decisions]]
- [[Claude Web Design Standards]]
- [[Design Decisions - 2026-07-06]]
