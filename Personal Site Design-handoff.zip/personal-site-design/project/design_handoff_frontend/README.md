# Handoff: richardkern.nz Frontend (Phase 03 — "Cover & Pages")

## Overview

Hi-fi design for all public pages of richardkern.nz — a personal portfolio + blog (Next.js 16 App Router + Payload CMS v3 + Tailwind 4 + shadcn/ui + PostgreSQL, repo `richardkern-nz`). This package is the visual handoff for **Phase 03 — Frontend** of the build plan in Richard's vault (`30 - Projects/Personal Site/`).

The direction is **"Cover & Pages" with a logbook layer**: a hardback field notebook — quiet paper pages, the dark cover material showing only at the homepage spine / footer / code blocks, and entry metadata set like a log (mono entry numbers and dates).

## About the Design Files

`Design Explorations.dc.html` (open in a browser with `support.js` beside it) is a **design reference created in HTML** — it shows intended look, not production code. **Recreate the designs in the existing Next.js/Tailwind/Payload codebase using its established patterns** (Tailwind utility classes, `next/font`, existing collection queries). Do not ship any HTML from this bundle.

The file is a stacked exploration canvas. **Only these mocks are the locked spec** (each labelled with an id badge in the file):

- **Home**: option `3b` layout with the `4b` hero type and `4a/4b` logbook entry rails (see per-screen spec below — it consolidates them)
- **Post**: `5a` · **Posts index**: `5b` · **Work index**: `5c` · **Project**: `5d` · **About**: `5e` · **404**: `5f`
- **Inner chrome**: `3d` with the header wordmark at **16px** (the file's turn-5 pages already show this)
- **Mobile home**: `6a` — the locked system at 375

Everything else in the file (turns 1, 2, most of 3–4) is rejected exploration history. Ignore it.

## Fidelity

**High-fidelity.** Colors, type faces/sizes/weights, spacing, and copy tone in the turn-5 mocks are final intent. Recreate pixel-faithfully at 1440; adapt spacing proportionally at other widths per the responsive rules below. Desktop values are authoritative; mobile beyond the documented patterns is implementer's judgment within the same system.

## Authoritative documents

`vault/Design Spec.md` in this bundle is the **full page-by-page spec** (IA, content model, page purposes, §4 visual direction, §5 fixed decisions). It is written to be the single handoff document — read it first, in full. `vault/Design Decisions - 2026-07-06.md` records why each call was made.

**Vault task:** these two files belong in Richard's Obsidian vault at `~/vaults/richard-kb/30 - Projects/Personal Site/`. `Design Spec.md` **overwrites** the existing note of that name; the decision log is new. Please write them there as part of this handoff (Claude Code has filesystem access; this design environment did not).

Also governing: the vault note `40 - Resources/Reference Docs/Claude Web Design Standards.md` — hard bans and end-of-build checklist apply.

## Design Tokens

Colors (define as CSS custom properties / Tailwind theme tokens):

| Token | Hex | Use |
|---|---|---|
| `charcoal` (Bush Charcoal) | `#171B16` | spine rail, footer, code blocks — nowhere else |
| `paper` | `#F7F5EF` | page background; text on charcoal |
| `ink` | `#22261F` | body text on paper |
| `fern` | `#2A5A43` | accent on paper: links, tags, active nav |
| `moss` | `#8FB8A5` | accent on charcoal only (fern fails AA there) |
| `haze` | `#5E6459` | muted text on paper; on charcoal use `rgba(247,245,239,.65)` |

Hairlines: `rgba(34,38,31,.07)` between entries, `rgba(34,38,31,.09–.12)` for section rules/borders. On charcoal: `rgba(247,245,239,.22)` borders.

Type (load via `next/font`, `font-display: swap`; Schibsted Grotesk + Source Serif 4 from Google Fonts, Geist already in repo):

| Role | Face | Key sizes in mocks |
|---|---|---|
| Display | Schibsted Grotesk | home name 108px/0.98 w700 ls-.035em (lowercase); page H1 44px/1.05 w700 ls-.03em; post title 46px/1.08; index entry titles 22px/1.25 w600 ls-.02em |
| Body | Source Serif 4 | post/project body 18–19px/1.7; index descriptions 15.5px/1.6; home bio 21px/1.6; byline italic 14.5px |
| UI | Geist Sans | nav 13px w500; section labels 11px w500 uppercase ls.16em; links 13–13.5px w500 fern; small meta 12px |
| Code + meta | Geist Mono | wordmark (16px header / 12.5px footer / 13px spine, all w500 ls.02em); logbook rails 11–12px; code 14px/1.75; tech lists 11.5px |

Radius: **6px on code blocks only**; everything else square. Shadows: none. Spacing rhythm: 96px page gutters at 1440; ~68–80px top padding on inner pages; 26–28px entry padding; content measures 720px (posts/about), 880px (indexes/project), 1080px (work grid).

## Screens

All layout detail is in `vault/Design Spec.md` §3 with mock ids; summary:

- **Home `/`** — no header/footer. Left spine rail 86px `charcoal`: vertical wordmark top (writing-mode:vertical-rl, rotated, reads bottom-up), 3 social glyphs bottom (30px circles, 1px `rgba(247,245,239,.22)` border, mono 9.5px). Main: nav top-right; `richard` ⏎ `kern` + fern full-stop at 108px; serif bio (from SiteSettings); two columns (writing / selected work) with logbook rails (`N°07` ⏎ `28.06` mono over serif titles). Data: 3 recent published posts, ≤3 featured projects. At 375px the spine becomes a charcoal top bar (wordmark left, socials right — mock `6a`).
- **Post `/posts/[slug]`** — mono meta line `N°06 · 14.06.2026 · tags` (tags fern) → 46px title → serif body at 720px measure → charcoal code blocks (radius 6, mono filename caption at 10.5px `rgba(247,245,239,.4)`, syntax: keywords `moss`, strings `#D9C79E`, comments `#98A19B`, base `#E9E7E0`) → byline (hairline top, italic serif + fern social links + "← Full log").
- **Posts index `/posts`** — H1 "Posts", tag filter as quiet text row (active = fern + 1.5px underline, "All" resets), entries: 110px mono rail (`N°` + `DD.MM.YY`) / Schibsted title / serif description / fern tags. Pagination `p.1 / 2` + "Older →". Entry N° = real chronological position of published posts.
- **Work index `/work`** — H1 "Work", two-up grid (56px gap): 16:10 cover, title + `year · featured` mono, one-line Geist description, mono fern tech list. Featured first, then year desc.
- **Project `/work/[slug]`** — mono meta (`year · tech`), title, **live/repo links directly under title** (fern, ↗), serif body, 16:10 two-up gallery, "← All work".
- **About `/about`** — H1, three serif paragraphs, hairline, fern social links. No CTA, no services pitch (fixed decision).
- **404** — header only; mono `N°404 · entry not found`, 64px "This page isn't in the log.", serif line, links to Posts and Work.
- **Inner chrome** — header: wordmark 16px mono (links home) + nav, hairline bottom; active section fern + underline. Footer: charcoal; wordmark 12.5px (moss `.nz`), nav, socials, `© 2026 Richard Kern` — populated from Header/Footer globals + SiteSettings.

## Interactions & Behavior

- All list entries are whole-row/card links; nothing else competes with them. Hover: title picks up an underline or shifts to fern — keep it minimal and consistent.
- Tag filter is server-rendered via `?tag=`; active filter visible and dismissible. Empty result states say so plainly. Pagination hidden with a single page.
- Focus states: visible, fern (e.g. 2px outline offset 2px) on every interactive element.
- Motion: **at most one considered moment** (suggest a single staggered reveal of name → bio → columns on home load, 300–500ms, ease-out). No scroll-triggered per-section fade-ins. Respect `prefers-reduced-motion`.
- Wordmark `.nz` is fern on paper, moss on charcoal — everywhere.

## State & Data

No client state beyond the template's existing patterns. All content from Payload (collections/globals per Design Spec §2): home queries 3 recent published posts + ≤3 featured published projects; drafts must never render publicly. Entry N° derived from published-post chronological order (display device; may shift on unpublish — accepted).

## Responsive

Build mobile-first; test 375 / 768 / 1024 / 1440. Home spine→top-bar pattern at small widths; writing/work columns stack; type scales down (name ~48–56px at 375, body stays ≥16px serif). Tap targets ≥44px. No horizontal scroll.

## Assets

- No image assets in this bundle. Striped boxes in the mocks are **placeholders** for Payload Media (project covers 16:10, galleries) — real images come from the CMS.
- Social icons: mocks use circled mono glyphs (`gh`/`in`/`@`) — implementer may keep these (they're on-theme) or use lucide icons already in the repo, sized ≤16px, at the mock positions.
- Favicon: derive from wordmark — `rk.` mono on Bush Charcoal; fern dot alone at 16px. Replace `public/favicon.svg` / `.ico` and delete `website-template-OG.webp`.

## Files

- `screenshots/` — PNGs of every locked mock: `01-home` (4b/3b composite), `02-home-mobile-375` (6a), `03-inner-chrome` (3d), `04-post` (5a), `05-posts-index` (5b), `06-work-index` (5c), `07-project` (5d), `08-about` (5e), `09-404` (5f). Captured scaled-to-fit; exact values come from this README and the HTML, not from measuring the PNGs.
- `Design Explorations.dc.html` + `support.js` — the visual reference (open locally in a browser; use ids 5a–5f, 3b, 3d, 4b, 6a)
- `vault/Design Spec.md` — authoritative spec → also write to vault (overwrites existing)
- `vault/Design Decisions - 2026-07-06.md` — decision log → also write to vault (new)

## Codebase notes

- `src/app/(frontend)/page.tsx` is an obsolete dark homepage predating this direction — replace it.
- Delete `/search` route + `next/seed` at launch (spec §1); keep `next/preview` routes.
- Fonts: add Schibsted Grotesk + Source Serif 4 via `next/font`; Geist Sans/Mono already loaded. Remove any Bricolage references if present.
- Existing shadcn/tailwind theme vars in `globals.css` are template defaults — introduce the §4 tokens deliberately rather than mapping onto the old names blindly.
